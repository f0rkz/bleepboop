# No Burn Metal

NO LONGER FLAMMABLE
 - Steel
 - Plasteel
 - Gold
 - Silver

STILL NOT FLAMMABLE
 - Uranium
 - Jade

Utilizes xpath patching to be a cleaner method. Doesn't dirty the GUI with ShowModDesignators loaded. 
All my version does is make sure in the case of catastrophic failure (Jade, or Uranium becoming flammable), that these values will persist.
 

(xpath patching of metals for the game: Rimworld)
